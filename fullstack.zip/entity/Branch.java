package com.hitachi.coe.fullstack.entity;

import com.hitachi.coe.fullstack.entity.base.BaseAudit;
import com.hitachi.coe.fullstack.entity.base.BaseReadonlyEntity;
import jdk.nashorn.internal.objects.annotations.Getter;
import jdk.nashorn.internal.objects.annotations.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = "branch")
public class Branch extends BaseAudit implements BaseReadonlyEntity<Integer> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String code;

    private String name;

    // bi-directional many-to-one association to Location
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id")
    private Location location;

    // bi-directional one-to-one association to Employee
    @OneToOne(mappedBy = "branch", fetch = FetchType.LAZY)
    private Employee employee;

}
