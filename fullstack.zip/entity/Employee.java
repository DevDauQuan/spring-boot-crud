package com.hitachi.coe.fullstack.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import com.hitachi.coe.fullstack.entity.base.BaseAudit;
import com.hitachi.coe.fullstack.entity.base.BaseReadonlyEntity;

import lombok.Getter;
import lombok.Setter;


/**
 * The persistent class for the employee database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name="employee")
public class Employee extends BaseAudit implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "email")
	private String email;

	@Column(name = "hcc_id")
	private String hccId;

	@Column(name = "ldap")
	private String ldap;

	@Temporal(TemporalType.DATE)
	@Column(name = "legal_entity_hire_date")
	private Date legalEntityHireDate;

	@Column(name = "name")
	private String name;

	@Column(name = "branch_id")
	private Integer branchId;

	// bi-directional one-to-one association to Branch
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "id")
	private Branch branch;

	// bi-directional many-to-one association to CoeCoreTeam
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "coe_core_team_id")
	private CoeCoreTeam coeCoreTeam;

	// bi-directional many-to-one association to Practice
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "practice_id")
	private Practice practice;

	// bi-directional many-to-one association to EmployeeEvaluation
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<EmployeeEvaluation> employeeEvaluations;

	// bi-directional many-to-one association to EmployeeLevel
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<EmployeeLevel> employeeLevels;

	// bi-directional many-to-one association to EmployeeSkill
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<EmployeeSkill> employeeSkills;

	// bi-directional many-to-one association to EmployeeStatus
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<EmployeeStatus> employeeStatuses;

	// bi-directional many-to-one association to EmployeeUtilization
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<EmployeeUtilization> employeeUtilizations;

	// bi-directional many-to-one association to ProjectFeedback
	@OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
	private List<ProjectFeedback> projectFeedbacks;


}