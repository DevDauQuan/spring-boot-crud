package com.hitachi.coe.fullstack.transformation;

import com.hitachi.coe.fullstack.entity.CenterOfExcellence;
import com.hitachi.coe.fullstack.model.BranchModel;
import com.hitachi.coe.fullstack.model.CenterOfExcellenceModel;
import com.hitachi.coe.fullstack.transformation.base.AbstractCopyPropertiesTransformer;
import com.hitachi.coe.fullstack.transformation.base.EntityToModelTransformer;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * This CenterOfExcellenceTransformer is transform entity to DTO.
 *
 * @author lphanhoangle
 *
 */
public class CenterOfExcellenceTransformer extends AbstractCopyPropertiesTransformer<CenterOfExcellence, CenterOfExcellenceModel>
        implements EntityToModelTransformer<CenterOfExcellence, CenterOfExcellenceModel, Integer> {

    /**
     * Transformer array entities to array DTO.
     *
     * @param entities {@link List} of {@link CenterOfExcellence}
     * @return {@link List} of {@link CenterOfExcellenceModel}
     */
    public List<CenterOfExcellenceModel> applyList(List<CenterOfExcellence> entities) {
        if (null == entities || entities.isEmpty()) {
            return Collections.emptyList();
        }

        return entities.stream().map(this::apply)
                .collect(Collectors.toList());
    }
}
