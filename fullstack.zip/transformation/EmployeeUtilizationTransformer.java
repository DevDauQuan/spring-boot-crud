package com.hitachi.coe.fullstack.transformation;

import com.hitachi.coe.fullstack.entity.Branch;
import com.hitachi.coe.fullstack.entity.EmployeeUtilization;
import com.hitachi.coe.fullstack.model.BranchModel;
import com.hitachi.coe.fullstack.model.EmployeeUtilizationModel;
import com.hitachi.coe.fullstack.transformation.base.AbstractCopyPropertiesTransformer;
import com.hitachi.coe.fullstack.transformation.base.EntityToModelTransformer;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This EmployeeUtilizationTransformer is transform Entity to DTO
 *
 * @author lphanhoangle
 *
 * This is still like this EmployeeStatus, the @Id is Date, not Integer like everything else
 */
public class EmployeeUtilizationTransformer extends AbstractCopyPropertiesTransformer<EmployeeUtilization, EmployeeUtilizationModel>
        implements EntityToModelTransformer<EmployeeUtilization, EmployeeUtilizationModel, Date> {
    /**
     * Transformer array entities to array DTO.
     *
     * @param entities {@link List} of {@link EmployeeUtilization}
     * @return {@link List} of {@link EmployeeUtilizationModel}
     */
    public List<EmployeeUtilizationModel> applyList(List<EmployeeUtilization> entities) {
        if (null == entities || entities.isEmpty()) {
            return Collections.emptyList();
        }

        return entities.stream().map(this::apply)
                .collect(Collectors.toList());
    }
}
