package com.hitachi.coe.fullstack.transformation;

import com.hitachi.coe.fullstack.entity.Branch;
import com.hitachi.coe.fullstack.model.BranchModel;
import com.hitachi.coe.fullstack.transformation.base.AbstractCopyPropertiesTransformer;
import com.hitachi.coe.fullstack.transformation.base.EntityToModelTransformer;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * The BranchTransformer is convert entity to DTO;
 *
 * @author lphanhoangle
 */
public class BranchTransformer extends AbstractCopyPropertiesTransformer<Branch, BranchModel>
        implements EntityToModelTransformer<Branch, BranchModel, Integer> {
    /**
     * Transformer array entities to array DTO.
     *
     * @param entities {@link List} of {@link Branch}
     * @return {@link List} of {@link BranchModel}
     */
    public List<BranchModel> applyList(List<Branch> entities) {
        if (null == entities || entities.isEmpty()) {
            return Collections.emptyList();
        }

        return entities.stream().map(this::apply)
                .collect(Collectors.toList());
    }
}
