package com.hitachi.coe.fullstack.model;

import com.hitachi.coe.fullstack.entity.Employee;
import com.hitachi.coe.fullstack.model.base.AuditModel;
import com.hitachi.coe.fullstack.model.base.BaseReadonlyModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
public class EmployeeUtilizationModel extends AuditModel<Date> {

    private Integer avaiableHours;

    private Integer billableHours;

    private Date endDate;

    private Integer ptoOracle;

    private Date startDate;

    private Employee employee;
}
