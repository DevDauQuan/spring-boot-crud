package com.hitachi.coe.fullstack.model;

import com.hitachi.coe.fullstack.entity.CoeCoreTeam;
import com.hitachi.coe.fullstack.model.base.AuditModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CenterOfExcellenceModel extends AuditModel<Integer> {

    private String code;

    private String name;

    private List<CoeCoreTeam> coeCoreTeam;
}
