package com.hitachi.coe.fullstack.model;

import com.hitachi.coe.fullstack.entity.Employee;
import com.hitachi.coe.fullstack.model.base.AuditModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
public class EmployeeStatusModel extends AuditModel<Date> {

    private Integer status;

    private Employee Employee;

}
