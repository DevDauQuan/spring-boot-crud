package com.hitachi.coe.fullstack.model;

import com.hitachi.coe.fullstack.entity.Branch;
import com.hitachi.coe.fullstack.model.base.AuditModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class LocationModel extends AuditModel<Integer> {

    private String code;

    private String name;

    private List<Branch> branches;

}
