package com.hitachi.coe.fullstack.model;

import com.hitachi.coe.fullstack.entity.CenterOfExcellence;
import com.hitachi.coe.fullstack.entity.Employee;
import com.hitachi.coe.fullstack.model.base.AuditModel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CoeCoreTeamModel extends AuditModel<Integer> {

    private String code;

    private String name;

    private Integer status;

    private CenterOfExcellence centerOfExcellence;

    private List<Employee> employees;

}
